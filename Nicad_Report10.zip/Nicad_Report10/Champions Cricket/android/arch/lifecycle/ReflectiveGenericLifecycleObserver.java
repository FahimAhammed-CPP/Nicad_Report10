package android.arch.lifecycle;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class ReflectiveGenericLifecycleObserver implements GenericLifecycleObserver {
  private static final int CALL_TYPE_NO_ARG = 0;
  
  private static final int CALL_TYPE_PROVIDER = 1;
  
  private static final int CALL_TYPE_PROVIDER_WITH_EVENT = 2;
  
  static final Map<Class, CallbackInfo> sInfoCache = (Map)new HashMap<Class<?>, CallbackInfo>();
  
  private final CallbackInfo mInfo;
  
  private final Object mWrapped;
  
  ReflectiveGenericLifecycleObserver(Object paramObject) {
    this.mWrapped = paramObject;
    this.mInfo = getInfo(this.mWrapped.getClass());
  }
  
  private static CallbackInfo createInfo(Class paramClass) {
    Class clazz = paramClass.getSuperclass();
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    if (clazz != null) {
      CallbackInfo callbackInfo1 = getInfo(clazz);
      if (callbackInfo1 != null)
        hashMap.putAll(callbackInfo1.mHandlerToEvent); 
    } 
    Method[] arrayOfMethod = paramClass.getDeclaredMethods();
    Class[] arrayOfClass = paramClass.getInterfaces();
    int j = arrayOfClass.length;
    int i;
    for (i = 0; i < j; i++) {
      for (Map.Entry<MethodReference, Lifecycle.Event> entry : (getInfo(arrayOfClass[i])).mHandlerToEvent.entrySet())
        verifyAndPutHandler((Map)hashMap, (MethodReference)entry.getKey(), (Lifecycle.Event)entry.getValue(), paramClass); 
    } 
    int k = arrayOfMethod.length;
    for (j = 0; j < k; j++) {
      Method method = arrayOfMethod[j];
      OnLifecycleEvent onLifecycleEvent = method.<OnLifecycleEvent>getAnnotation(OnLifecycleEvent.class);
      if (onLifecycleEvent != null) {
        Class[] arrayOfClass1 = method.getParameterTypes();
        i = 0;
        if (arrayOfClass1.length > 0) {
          i = 1;
          if (!arrayOfClass1[0].isAssignableFrom(LifecycleOwner.class))
            throw new IllegalArgumentException("invalid parameter type. Must be one and instanceof LifecycleOwner"); 
        } 
        Lifecycle.Event event = onLifecycleEvent.value();
        if (arrayOfClass1.length > 1) {
          i = 2;
          if (!arrayOfClass1[1].isAssignableFrom(Lifecycle.Event.class))
            throw new IllegalArgumentException("invalid parameter type. second arg must be an event"); 
          if (event != Lifecycle.Event.ON_ANY)
            throw new IllegalArgumentException("Second arg is supported only for ON_ANY value"); 
        } 
        if (arrayOfClass1.length > 2)
          throw new IllegalArgumentException("cannot have more than 2 params"); 
        verifyAndPutHandler((Map)hashMap, new MethodReference(i, method), event, paramClass);
      } 
    } 
    CallbackInfo callbackInfo = new CallbackInfo((Map)hashMap);
    sInfoCache.put(paramClass, callbackInfo);
    return callbackInfo;
  }
  
  private static CallbackInfo getInfo(Class paramClass) {
    CallbackInfo callbackInfo = sInfoCache.get(paramClass);
    return (callbackInfo != null) ? callbackInfo : createInfo(paramClass);
  }
  
  private void invokeCallback(MethodReference paramMethodReference, LifecycleOwner paramLifecycleOwner, Lifecycle.Event paramEvent) {
    try {
      switch (paramMethodReference.mCallType) {
        case 0:
          paramMethodReference.mMethod.invoke(this.mWrapped, new Object[0]);
          return;
        case 1:
          paramMethodReference.mMethod.invoke(this.mWrapped, new Object[] { paramLifecycleOwner });
          return;
        case 2:
          paramMethodReference.mMethod.invoke(this.mWrapped, new Object[] { paramLifecycleOwner, paramEvent });
          return;
      } 
    } catch (InvocationTargetException invocationTargetException) {
      throw new RuntimeException("Failed to call observer method", invocationTargetException.getCause());
    } catch (IllegalAccessException illegalAccessException) {
      throw new RuntimeException(illegalAccessException);
    } 
  }
  
  private void invokeCallbacks(CallbackInfo paramCallbackInfo, LifecycleOwner paramLifecycleOwner, Lifecycle.Event paramEvent) {
    invokeMethodsForEvent(paramCallbackInfo.mEventToHandlers.get(paramEvent), paramLifecycleOwner, paramEvent);
    invokeMethodsForEvent(paramCallbackInfo.mEventToHandlers.get(Lifecycle.Event.ON_ANY), paramLifecycleOwner, paramEvent);
  }
  
  private void invokeMethodsForEvent(List<MethodReference> paramList, LifecycleOwner paramLifecycleOwner, Lifecycle.Event paramEvent) {
    if (paramList != null) {
      int i;
      for (i = paramList.size() - 1; i >= 0; i--)
        invokeCallback(paramList.get(i), paramLifecycleOwner, paramEvent); 
    } 
  }
  
  private static void verifyAndPutHandler(Map<MethodReference, Lifecycle.Event> paramMap, MethodReference paramMethodReference, Lifecycle.Event paramEvent, Class paramClass) {
    Method method;
    Lifecycle.Event event = paramMap.get(paramMethodReference);
    if (event != null && paramEvent != event) {
      method = paramMethodReference.mMethod;
      throw new IllegalArgumentException("Method " + method.getName() + " in " + paramClass.getName() + " already declared with different @OnLifecycleEvent value: previous" + " value " + event + ", new value " + paramEvent);
    } 
    if (event == null)
      method.put(paramMethodReference, paramEvent); 
  }
  
  public void onStateChanged(LifecycleOwner paramLifecycleOwner, Lifecycle.Event paramEvent) {
    invokeCallbacks(this.mInfo, paramLifecycleOwner, paramEvent);
  }
  
  static class CallbackInfo {
    final Map<Lifecycle.Event, List<ReflectiveGenericLifecycleObserver.MethodReference>> mEventToHandlers;
    
    final Map<ReflectiveGenericLifecycleObserver.MethodReference, Lifecycle.Event> mHandlerToEvent;
    
    CallbackInfo(Map<ReflectiveGenericLifecycleObserver.MethodReference, Lifecycle.Event> param1Map) {
      this.mHandlerToEvent = param1Map;
      this.mEventToHandlers = new HashMap<Lifecycle.Event, List<ReflectiveGenericLifecycleObserver.MethodReference>>();
      for (Map.Entry<ReflectiveGenericLifecycleObserver.MethodReference, Lifecycle.Event> entry : param1Map.entrySet()) {
        Lifecycle.Event event = (Lifecycle.Event)entry.getValue();
        List<ReflectiveGenericLifecycleObserver.MethodReference> list2 = this.mEventToHandlers.get(event);
        List<ReflectiveGenericLifecycleObserver.MethodReference> list1 = list2;
        if (list2 == null) {
          list1 = new ArrayList();
          this.mEventToHandlers.put(event, list1);
        } 
        list1.add((ReflectiveGenericLifecycleObserver.MethodReference)entry.getKey());
      } 
    }
  }
  
  static class MethodReference {
    final int mCallType;
    
    final Method mMethod;
    
    MethodReference(int param1Int, Method param1Method) {
      this.mCallType = param1Int;
      this.mMethod = param1Method;
      this.mMethod.setAccessible(true);
    }
    
    public boolean equals(Object param1Object) {
      if (this != param1Object) {
        if (param1Object == null || getClass() != param1Object.getClass())
          return false; 
        param1Object = param1Object;
        if (this.mCallType != ((MethodReference)param1Object).mCallType || !this.mMethod.getName().equals(((MethodReference)param1Object).mMethod.getName()))
          return false; 
      } 
      return true;
    }
    
    public int hashCode() {
      return this.mCallType * 31 + this.mMethod.getName().hashCode();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Champions Cricket-dex2jar.jar!\android\arch\lifecycle\ReflectiveGenericLifecycleObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */