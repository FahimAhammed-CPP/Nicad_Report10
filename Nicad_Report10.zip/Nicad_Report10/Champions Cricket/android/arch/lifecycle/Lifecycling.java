package android.arch.lifecycle;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RestrictTo;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Map;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
class Lifecycling {
  private static Map<Class, Constructor<? extends GenericLifecycleObserver>> sCallbackCache = (Map)new HashMap<Class<?>, Constructor<? extends GenericLifecycleObserver>>();
  
  private static Constructor<? extends GenericLifecycleObserver> sREFLECTIVE;
  
  static String getAdapterName(String paramString) {
    return paramString.replace(".", "_") + "_LifecycleAdapter";
  }
  
  @NonNull
  static GenericLifecycleObserver getCallback(Object paramObject) {
    if (paramObject instanceof GenericLifecycleObserver)
      return (GenericLifecycleObserver)paramObject; 
    try {
      Class<?> clazz = paramObject.getClass();
      Constructor<GenericLifecycleObserver> constructor = (Constructor)sCallbackCache.get(clazz);
      if (constructor != null)
        return constructor.newInstance(new Object[] { paramObject }); 
      Constructor<? extends GenericLifecycleObserver> constructor2 = getGeneratedAdapterConstructor(clazz);
      if (constructor2 != null) {
        Constructor<? extends GenericLifecycleObserver> constructor3 = constructor2;
        if (!constructor2.isAccessible()) {
          constructor2.setAccessible(true);
          constructor3 = constructor2;
        } 
        sCallbackCache.put(clazz, constructor3);
        return constructor3.newInstance(new Object[] { paramObject });
      } 
      Constructor<? extends GenericLifecycleObserver> constructor1 = sREFLECTIVE;
      sCallbackCache.put(clazz, constructor1);
      return constructor1.newInstance(new Object[] { paramObject });
    } catch (IllegalAccessException illegalAccessException) {
      throw new RuntimeException(illegalAccessException);
    } catch (InstantiationException instantiationException) {
      throw new RuntimeException(instantiationException);
    } catch (InvocationTargetException invocationTargetException) {
      throw new RuntimeException(invocationTargetException);
    } 
  }
  
  @Nullable
  private static Constructor<? extends GenericLifecycleObserver> getGeneratedAdapterConstructor(Class<?> paramClass) {
    String str1;
    Package package_ = paramClass.getPackage();
    if (package_ != null) {
      str1 = package_.getName();
    } else {
      str1 = "";
    } 
    String str2 = paramClass.getCanonicalName();
    if (str2 != null) {
      if (!str1.isEmpty())
        str2 = str2.substring(str1.length() + 1); 
      str2 = getAdapterName(str2);
      try {
        if (str1.isEmpty()) {
          str1 = str2;
          return (Constructor)Class.forName(str1).getDeclaredConstructor(new Class[] { paramClass });
        } 
        str1 = str1 + "." + str2;
        return (Constructor)Class.forName(str1).getDeclaredConstructor(new Class[] { paramClass });
      } catch (ClassNotFoundException classNotFoundException) {
        paramClass = paramClass.getSuperclass();
        if (paramClass != null)
          return getGeneratedAdapterConstructor(paramClass); 
      } catch (NoSuchMethodException noSuchMethodException) {
        throw new RuntimeException(noSuchMethodException);
      } 
    } 
    return null;
  }
  
  static {
    try {
      sREFLECTIVE = ReflectiveGenericLifecycleObserver.class.getDeclaredConstructor(new Class[] { Object.class });
    } catch (NoSuchMethodException noSuchMethodException) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Champions Cricket-dex2jar.jar!\android\arch\lifecycle\Lifecycling.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */