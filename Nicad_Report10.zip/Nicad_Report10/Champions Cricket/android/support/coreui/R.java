package android.support.coreui;

public final class R {
  public static final class attr {
    public static final int font = 2130772170;
    
    public static final int fontProviderAuthority = 2130772163;
    
    public static final int fontProviderCerts = 2130772166;
    
    public static final int fontProviderFetchStrategy = 2130772167;
    
    public static final int fontProviderFetchTimeout = 2130772168;
    
    public static final int fontProviderPackage = 2130772164;
    
    public static final int fontProviderQuery = 2130772165;
    
    public static final int fontStyle = 2130772169;
    
    public static final int fontWeight = 2130772171;
  }
  
  public static final class bool {
    public static final int abc_action_bar_embed_tabs = 2131230720;
  }
  
  public static final class color {
    public static final int notification_action_color_filter = 2131296256;
    
    public static final int notification_icon_bg_color = 2131296327;
    
    public static final int ripple_material_light = 2131296338;
    
    public static final int secondary_text_default_material_light = 2131296340;
  }
  
  public static final class dimen {
    public static final int compat_button_inset_horizontal_material = 2131099745;
    
    public static final int compat_button_inset_vertical_material = 2131099746;
    
    public static final int compat_button_padding_horizontal_material = 2131099747;
    
    public static final int compat_button_padding_vertical_material = 2131099748;
    
    public static final int compat_control_corner_material = 2131099749;
    
    public static final int notification_action_icon_size = 2131099759;
    
    public static final int notification_action_text_size = 2131099760;
    
    public static final int notification_big_circle_margin = 2131099761;
    
    public static final int notification_content_margin_start = 2131099666;
    
    public static final int notification_large_icon_height = 2131099762;
    
    public static final int notification_large_icon_width = 2131099763;
    
    public static final int notification_main_column_padding_top = 2131099667;
    
    public static final int notification_media_narrow_margin = 2131099668;
    
    public static final int notification_right_icon_size = 2131099764;
    
    public static final int notification_right_side_padding_top = 2131099664;
    
    public static final int notification_small_icon_background_padding = 2131099765;
    
    public static final int notification_small_icon_size_as_large = 2131099766;
    
    public static final int notification_subtext_size = 2131099767;
    
    public static final int notification_top_pad = 2131099768;
    
    public static final int notification_top_pad_large_text = 2131099769;
  }
  
  public static final class drawable {
    public static final int notification_action_background = 2130837648;
    
    public static final int notification_bg = 2130837649;
    
    public static final int notification_bg_low = 2130837650;
    
    public static final int notification_bg_low_normal = 2130837651;
    
    public static final int notification_bg_low_pressed = 2130837652;
    
    public static final int notification_bg_normal = 2130837653;
    
    public static final int notification_bg_normal_pressed = 2130837654;
    
    public static final int notification_icon_background = 2130837655;
    
    public static final int notification_template_icon_bg = 2130837660;
    
    public static final int notification_template_icon_low_bg = 2130837661;
    
    public static final int notification_tile_bg = 2130837656;
    
    public static final int notify_panel_notification_icon_bg = 2130837657;
  }
  
  public static final class id {
    public static final int action_container = 2131361929;
    
    public static final int action_divider = 2131361936;
    
    public static final int action_image = 2131361930;
    
    public static final int action_text = 2131361931;
    
    public static final int actions = 2131361945;
    
    public static final int async = 2131361824;
    
    public static final int blocking = 2131361825;
    
    public static final int chronometer = 2131361941;
    
    public static final int forever = 2131361826;
    
    public static final int icon = 2131361874;
    
    public static final int icon_group = 2131361946;
    
    public static final int info = 2131361942;
    
    public static final int italic = 2131361827;
    
    public static final int line1 = 2131361797;
    
    public static final int line3 = 2131361798;
    
    public static final int normal = 2131361807;
    
    public static final int notification_background = 2131361943;
    
    public static final int notification_main_column = 2131361938;
    
    public static final int notification_main_column_container = 2131361937;
    
    public static final int right_icon = 2131361944;
    
    public static final int right_side = 2131361939;
    
    public static final int text = 2131361802;
    
    public static final int text2 = 2131361803;
    
    public static final int time = 2131361940;
    
    public static final int title = 2131361804;
  }
  
  public static final class integer {
    public static final int status_bar_notification_info_maxnum = 2131427333;
  }
  
  public static final class layout {
    public static final int notification_action = 2130903078;
    
    public static final int notification_action_tombstone = 2130903079;
    
    public static final int notification_template_custom_big = 2130903086;
    
    public static final int notification_template_icon_group = 2130903087;
    
    public static final int notification_template_part_chronometer = 2130903091;
    
    public static final int notification_template_part_time = 2130903092;
  }
  
  public static final class string {
    public static final int status_bar_notification_info_overflow = 2131034180;
  }
  
  public static final class style {
    public static final int TextAppearance_Compat_Notification = 2131165327;
    
    public static final int TextAppearance_Compat_Notification_Info = 2131165328;
    
    public static final int TextAppearance_Compat_Notification_Line2 = 2131165472;
    
    public static final int TextAppearance_Compat_Notification_Time = 2131165331;
    
    public static final int TextAppearance_Compat_Notification_Title = 2131165333;
    
    public static final int Widget_Compat_NotificationActionContainer = 2131165335;
    
    public static final int Widget_Compat_NotificationActionText = 2131165336;
  }
  
  public static final class styleable {
    public static final int[] FontFamily = new int[] { 2130772163, 2130772164, 2130772165, 2130772166, 2130772167, 2130772168 };
    
    public static final int[] FontFamilyFont = new int[] { 2130772169, 2130772170, 2130772171 };
    
    public static final int FontFamilyFont_font = 1;
    
    public static final int FontFamilyFont_fontStyle = 0;
    
    public static final int FontFamilyFont_fontWeight = 2;
    
    public static final int FontFamily_fontProviderAuthority = 0;
    
    public static final int FontFamily_fontProviderCerts = 3;
    
    public static final int FontFamily_fontProviderFetchStrategy = 4;
    
    public static final int FontFamily_fontProviderFetchTimeout = 5;
    
    public static final int FontFamily_fontProviderPackage = 1;
    
    public static final int FontFamily_fontProviderQuery = 2;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Champions Cricket-dex2jar.jar!\android\support\coreui\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */