package android.support.v4.app;

import android.app.RemoteInput;
import android.content.ClipData;
import android.content.ClipDescription;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import java.util.HashMap;
import java.util.Map;

@RequiresApi(20)
class RemoteInputCompatApi20 {
  private static final String EXTRA_DATA_TYPE_RESULTS_DATA = "android.remoteinput.dataTypeResultsData";
  
  public static void addDataResultToIntent(RemoteInputCompatBase.RemoteInput paramRemoteInput, Intent paramIntent, Map<String, Uri> paramMap) {
    Intent intent2 = getClipDataIntentFromIntent(paramIntent);
    Intent intent1 = intent2;
    if (intent2 == null)
      intent1 = new Intent(); 
    for (Map.Entry<String, Uri> entry : paramMap.entrySet()) {
      String str = (String)entry.getKey();
      Uri uri = (Uri)entry.getValue();
      if (str != null) {
        Bundle bundle2 = intent1.getBundleExtra(getExtraResultsKeyForData(str));
        Bundle bundle1 = bundle2;
        if (bundle2 == null)
          bundle1 = new Bundle(); 
        bundle1.putString(paramRemoteInput.getResultKey(), uri.toString());
        intent1.putExtra(getExtraResultsKeyForData(str), bundle1);
      } 
    } 
    paramIntent.setClipData(ClipData.newIntent("android.remoteinput.results", intent1));
  }
  
  static void addResultsToIntent(RemoteInputCompatBase.RemoteInput[] paramArrayOfRemoteInput, Intent paramIntent, Bundle paramBundle) {
    Bundle bundle = getResultsFromIntent(paramIntent);
    if (bundle != null) {
      bundle.putAll(paramBundle);
      paramBundle = bundle;
    } 
    int j = paramArrayOfRemoteInput.length;
    for (int i = 0; i < j; i++) {
      RemoteInputCompatBase.RemoteInput remoteInput = paramArrayOfRemoteInput[i];
      Map<String, Uri> map = getDataResultsFromIntent(paramIntent, remoteInput.getResultKey());
      RemoteInput.addResultsToIntent(fromCompat(new RemoteInputCompatBase.RemoteInput[] { remoteInput }, ), paramIntent, paramBundle);
      if (map != null)
        addDataResultToIntent(remoteInput, paramIntent, map); 
    } 
  }
  
  static RemoteInput[] fromCompat(RemoteInputCompatBase.RemoteInput[] paramArrayOfRemoteInput) {
    if (paramArrayOfRemoteInput == null)
      return null; 
    RemoteInput[] arrayOfRemoteInput = new RemoteInput[paramArrayOfRemoteInput.length];
    int i = 0;
    while (true) {
      RemoteInputCompatBase.RemoteInput remoteInput;
      RemoteInput[] arrayOfRemoteInput1 = arrayOfRemoteInput;
      if (i < paramArrayOfRemoteInput.length) {
        remoteInput = paramArrayOfRemoteInput[i];
        arrayOfRemoteInput[i] = (new RemoteInput.Builder(remoteInput.getResultKey())).setLabel(remoteInput.getLabel()).setChoices(remoteInput.getChoices()).setAllowFreeFormInput(remoteInput.getAllowFreeFormInput()).addExtras(remoteInput.getExtras()).build();
        i++;
        continue;
      } 
      return (RemoteInput[])remoteInput;
    } 
  }
  
  private static Intent getClipDataIntentFromIntent(Intent paramIntent) {
    ClipData clipData = paramIntent.getClipData();
    if (clipData != null) {
      ClipDescription clipDescription = clipData.getDescription();
      if (clipDescription.hasMimeType("text/vnd.android.intent") && clipDescription.getLabel().equals("android.remoteinput.results"))
        return clipData.getItemAt(0).getIntent(); 
    } 
    return null;
  }
  
  static Map<String, Uri> getDataResultsFromIntent(Intent paramIntent, String paramString) {
    paramIntent = getClipDataIntentFromIntent(paramIntent);
    if (paramIntent == null)
      return null; 
    HashMap<Object, Object> hashMap2 = new HashMap<Object, Object>();
    for (String str : paramIntent.getExtras().keySet()) {
      if (str.startsWith("android.remoteinput.dataTypeResultsData")) {
        String str1 = str.substring("android.remoteinput.dataTypeResultsData".length());
        if (str1 != null && !str1.isEmpty()) {
          str = paramIntent.getBundleExtra(str).getString(paramString);
          if (str != null && !str.isEmpty())
            hashMap2.put(str1, Uri.parse(str)); 
        } 
      } 
    } 
    HashMap<Object, Object> hashMap1 = hashMap2;
    if (hashMap2.isEmpty())
      hashMap1 = null; 
    return (Map)hashMap1;
  }
  
  private static String getExtraResultsKeyForData(String paramString) {
    return "android.remoteinput.dataTypeResultsData" + paramString;
  }
  
  static Bundle getResultsFromIntent(Intent paramIntent) {
    return RemoteInput.getResultsFromIntent(paramIntent);
  }
  
  static RemoteInputCompatBase.RemoteInput[] toCompat(RemoteInput[] paramArrayOfRemoteInput, RemoteInputCompatBase.RemoteInput.Factory paramFactory) {
    if (paramArrayOfRemoteInput == null)
      return null; 
    RemoteInputCompatBase.RemoteInput[] arrayOfRemoteInput = paramFactory.newArray(paramArrayOfRemoteInput.length);
    for (int i = 0; i < paramArrayOfRemoteInput.length; i++) {
      RemoteInput remoteInput = paramArrayOfRemoteInput[i];
      arrayOfRemoteInput[i] = paramFactory.build(remoteInput.getResultKey(), remoteInput.getLabel(), remoteInput.getChoices(), remoteInput.getAllowFreeFormInput(), remoteInput.getExtras(), null);
    } 
    return arrayOfRemoteInput;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Champions Cricket-dex2jar.jar!\android\support\v4\app\RemoteInputCompatApi20.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */