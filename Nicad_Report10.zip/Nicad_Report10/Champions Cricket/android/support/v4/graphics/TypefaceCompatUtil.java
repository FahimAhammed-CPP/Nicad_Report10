package android.support.v4.graphics;

import android.content.Context;
import android.content.res.Resources;
import android.net.Uri;
import android.os.CancellationSignal;
import android.os.Process;
import android.support.annotation.RequiresApi;
import android.support.annotation.RestrictTo;
import android.util.Log;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public class TypefaceCompatUtil {
  private static final String CACHE_FILE_PREFIX = ".font";
  
  private static final String TAG = "TypefaceCompatUtil";
  
  public static void closeQuietly(Closeable paramCloseable) {
    if (paramCloseable != null)
      try {
        paramCloseable.close();
        return;
      } catch (IOException iOException) {
        return;
      }  
  }
  
  @RequiresApi(19)
  public static ByteBuffer copyToDirectBuffer(Context paramContext, Resources paramResources, int paramInt) {
    File file = getTempFile(paramContext);
    if (file == null)
      return null; 
    try {
      boolean bool = copyToFile(file, paramResources, paramInt);
      if (!bool)
        return null; 
      return mmap(file);
    } finally {
      file.delete();
    } 
  }
  
  public static boolean copyToFile(File paramFile, Resources paramResources, int paramInt) {
    InputStream inputStream = null;
    try {
      InputStream inputStream1 = paramResources.openRawResource(paramInt);
      inputStream = inputStream1;
      return copyToFile(paramFile, inputStream1);
    } finally {
      closeQuietly(inputStream);
    } 
  }
  
  public static boolean copyToFile(File paramFile, InputStream paramInputStream) {
    FileOutputStream fileOutputStream;
    byte[] arrayOfByte = null;
    File file2 = null;
    try {
      InputStream inputStream;
      FileOutputStream fileOutputStream1 = new FileOutputStream(paramFile, false);
      try {
        arrayOfByte = new byte[1024];
        while (true)
          return true; 
      } catch (IOException null) {
        return false;
      } finally {
        paramInputStream = null;
        fileOutputStream = fileOutputStream1;
      } 
      closeQuietly(fileOutputStream);
      throw inputStream;
    } catch (IOException iOException) {
    
    } finally {
      closeQuietly(fileOutputStream);
    } 
    File file1 = paramFile;
    Log.e("TypefaceCompatUtil", "Error copying resource contents to temp file: " + iOException.getMessage());
    closeQuietly((Closeable)paramFile);
    return false;
  }
  
  public static File getTempFile(Context paramContext) {
    String str = ".font" + Process.myPid() + "-" + Process.myTid() + "-";
    for (int i = 0; i < 100; i++) {
      File file = new File(paramContext.getCacheDir(), str + i);
      try {
        boolean bool = file.createNewFile();
        if (bool)
          return file; 
      } catch (IOException iOException) {}
    } 
    return null;
  }
  
  @RequiresApi(19)
  public static ByteBuffer mmap(Context paramContext, CancellationSignal paramCancellationSignal, Uri paramUri) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getContentResolver : ()Landroid/content/ContentResolver;
    //   4: astore_0
    //   5: aload_0
    //   6: aload_2
    //   7: ldc 'r'
    //   9: aload_1
    //   10: invokevirtual openFileDescriptor : (Landroid/net/Uri;Ljava/lang/String;Landroid/os/CancellationSignal;)Landroid/os/ParcelFileDescriptor;
    //   13: astore_2
    //   14: new java/io/FileInputStream
    //   17: dup
    //   18: aload_2
    //   19: invokevirtual getFileDescriptor : ()Ljava/io/FileDescriptor;
    //   22: invokespecial <init> : (Ljava/io/FileDescriptor;)V
    //   25: astore #5
    //   27: aload #5
    //   29: invokevirtual getChannel : ()Ljava/nio/channels/FileChannel;
    //   32: astore_0
    //   33: aload_0
    //   34: invokevirtual size : ()J
    //   37: lstore_3
    //   38: aload_0
    //   39: getstatic java/nio/channels/FileChannel$MapMode.READ_ONLY : Ljava/nio/channels/FileChannel$MapMode;
    //   42: lconst_0
    //   43: lload_3
    //   44: invokevirtual map : (Ljava/nio/channels/FileChannel$MapMode;JJ)Ljava/nio/MappedByteBuffer;
    //   47: astore_0
    //   48: aload #5
    //   50: ifnull -> 62
    //   53: iconst_0
    //   54: ifeq -> 106
    //   57: aload #5
    //   59: invokevirtual close : ()V
    //   62: aload_2
    //   63: ifnull -> 74
    //   66: iconst_0
    //   67: ifeq -> 129
    //   70: aload_2
    //   71: invokevirtual close : ()V
    //   74: aload_0
    //   75: areturn
    //   76: astore_0
    //   77: new java/lang/NullPointerException
    //   80: dup
    //   81: invokespecial <init> : ()V
    //   84: athrow
    //   85: astore_0
    //   86: aload_0
    //   87: athrow
    //   88: astore_1
    //   89: aload_2
    //   90: ifnull -> 101
    //   93: aload_0
    //   94: ifnull -> 183
    //   97: aload_2
    //   98: invokevirtual close : ()V
    //   101: aload_1
    //   102: athrow
    //   103: astore_0
    //   104: aconst_null
    //   105: areturn
    //   106: aload #5
    //   108: invokevirtual close : ()V
    //   111: goto -> 62
    //   114: astore_1
    //   115: aconst_null
    //   116: astore_0
    //   117: goto -> 89
    //   120: astore_0
    //   121: new java/lang/NullPointerException
    //   124: dup
    //   125: invokespecial <init> : ()V
    //   128: athrow
    //   129: aload_2
    //   130: invokevirtual close : ()V
    //   133: aload_0
    //   134: areturn
    //   135: astore_0
    //   136: aload_0
    //   137: athrow
    //   138: astore_1
    //   139: aload #5
    //   141: ifnull -> 153
    //   144: aload_0
    //   145: ifnull -> 166
    //   148: aload #5
    //   150: invokevirtual close : ()V
    //   153: aload_1
    //   154: athrow
    //   155: astore #5
    //   157: aload_0
    //   158: aload #5
    //   160: invokevirtual addSuppressed : (Ljava/lang/Throwable;)V
    //   163: goto -> 153
    //   166: aload #5
    //   168: invokevirtual close : ()V
    //   171: goto -> 153
    //   174: astore_2
    //   175: aload_0
    //   176: aload_2
    //   177: invokevirtual addSuppressed : (Ljava/lang/Throwable;)V
    //   180: goto -> 101
    //   183: aload_2
    //   184: invokevirtual close : ()V
    //   187: goto -> 101
    //   190: astore_1
    //   191: aconst_null
    //   192: astore_0
    //   193: goto -> 139
    // Exception table:
    //   from	to	target	type
    //   5	14	103	java/io/IOException
    //   14	27	85	java/lang/Throwable
    //   14	27	114	finally
    //   27	48	135	java/lang/Throwable
    //   27	48	190	finally
    //   57	62	76	java/lang/Throwable
    //   57	62	114	finally
    //   70	74	120	java/lang/Throwable
    //   70	74	103	java/io/IOException
    //   77	85	85	java/lang/Throwable
    //   77	85	114	finally
    //   86	88	88	finally
    //   97	101	174	java/lang/Throwable
    //   97	101	103	java/io/IOException
    //   101	103	103	java/io/IOException
    //   106	111	85	java/lang/Throwable
    //   106	111	114	finally
    //   121	129	103	java/io/IOException
    //   129	133	103	java/io/IOException
    //   136	138	138	finally
    //   148	153	155	java/lang/Throwable
    //   148	153	114	finally
    //   153	155	85	java/lang/Throwable
    //   153	155	114	finally
    //   157	163	85	java/lang/Throwable
    //   157	163	114	finally
    //   166	171	85	java/lang/Throwable
    //   166	171	114	finally
    //   175	180	103	java/io/IOException
    //   183	187	103	java/io/IOException
  }
  
  @RequiresApi(19)
  private static ByteBuffer mmap(File paramFile) {
    try {
      Object object;
      FileInputStream fileInputStream = new FileInputStream(paramFile);
      try {
        FileChannel fileChannel = fileInputStream.getChannel();
        long l = fileChannel.size();
        MappedByteBuffer mappedByteBuffer = fileChannel.map(FileChannel.MapMode.READ_ONLY, 0L, l);
        if (fileInputStream != null) {
          if (false)
            try {
              return mappedByteBuffer;
            } catch (Throwable throwable1) {
              throw new NullPointerException();
            }  
        } else {
          return (ByteBuffer)throwable1;
        } 
        return (ByteBuffer)throwable1;
      } catch (Throwable null) {
        try {
          throw object;
        } finally {}
      } finally {
        paramFile = null;
      } 
      if (fileInputStream != null) {
        if (object != null) {
          try {
            fileInputStream.close();
          } catch (Throwable throwable) {}
          throw paramFile;
        } 
      } else {
        throw paramFile;
      } 
      throwable.close();
      throw paramFile;
    } catch (IOException iOException) {
      return null;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Champions Cricket-dex2jar.jar!\android\support\v4\graphics\TypefaceCompatUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */