package android.support.v4.graphics;

import android.graphics.Paint;
import android.graphics.Rect;
import android.support.annotation.NonNull;
import android.support.v4.util.Pair;

class PaintCompatApi14 {
  private static final String EM_STRING = "m";
  
  private static final String TOFU_STRING = "󟿽";
  
  private static final ThreadLocal<Pair<Rect, Rect>> sRectThreadLocal = new ThreadLocal<Pair<Rect, Rect>>();
  
  static boolean hasGlyph(@NonNull Paint paramPaint, @NonNull String paramString) {
    // Byte code:
    //   0: iconst_0
    //   1: istore #9
    //   3: aload_1
    //   4: invokevirtual length : ()I
    //   7: istore #6
    //   9: iload #6
    //   11: iconst_1
    //   12: if_icmpne -> 32
    //   15: aload_1
    //   16: iconst_0
    //   17: invokevirtual charAt : (I)C
    //   20: invokestatic isWhitespace : (C)Z
    //   23: ifeq -> 32
    //   26: iconst_1
    //   27: istore #8
    //   29: iload #8
    //   31: ireturn
    //   32: aload_0
    //   33: ldc '󟿽'
    //   35: invokevirtual measureText : (Ljava/lang/String;)F
    //   38: fstore_3
    //   39: aload_0
    //   40: ldc 'm'
    //   42: invokevirtual measureText : (Ljava/lang/String;)F
    //   45: fstore_2
    //   46: aload_0
    //   47: aload_1
    //   48: invokevirtual measureText : (Ljava/lang/String;)F
    //   51: fstore #4
    //   53: iload #9
    //   55: istore #8
    //   57: fload #4
    //   59: fconst_0
    //   60: fcmpl
    //   61: ifeq -> 29
    //   64: aload_1
    //   65: iconst_0
    //   66: aload_1
    //   67: invokevirtual length : ()I
    //   70: invokevirtual codePointCount : (II)I
    //   73: iconst_1
    //   74: if_icmple -> 149
    //   77: iload #9
    //   79: istore #8
    //   81: fload #4
    //   83: fconst_2
    //   84: fload_2
    //   85: fmul
    //   86: fcmpl
    //   87: ifgt -> 29
    //   90: fconst_0
    //   91: fstore_2
    //   92: iconst_0
    //   93: istore #5
    //   95: iload #5
    //   97: iload #6
    //   99: if_icmpge -> 138
    //   102: aload_1
    //   103: iload #5
    //   105: invokevirtual codePointAt : (I)I
    //   108: invokestatic charCount : (I)I
    //   111: istore #7
    //   113: fload_2
    //   114: aload_0
    //   115: aload_1
    //   116: iload #5
    //   118: iload #5
    //   120: iload #7
    //   122: iadd
    //   123: invokevirtual measureText : (Ljava/lang/String;II)F
    //   126: fadd
    //   127: fstore_2
    //   128: iload #5
    //   130: iload #7
    //   132: iadd
    //   133: istore #5
    //   135: goto -> 95
    //   138: iload #9
    //   140: istore #8
    //   142: fload #4
    //   144: fload_2
    //   145: fcmpl
    //   146: ifge -> 29
    //   149: fload #4
    //   151: fload_3
    //   152: fcmpl
    //   153: ifeq -> 158
    //   156: iconst_1
    //   157: ireturn
    //   158: invokestatic obtainEmptyRects : ()Landroid/support/v4/util/Pair;
    //   161: astore #10
    //   163: aload_0
    //   164: ldc '󟿽'
    //   166: iconst_0
    //   167: ldc '󟿽'
    //   169: invokevirtual length : ()I
    //   172: aload #10
    //   174: getfield first : Ljava/lang/Object;
    //   177: checkcast android/graphics/Rect
    //   180: invokevirtual getTextBounds : (Ljava/lang/String;IILandroid/graphics/Rect;)V
    //   183: aload_0
    //   184: aload_1
    //   185: iconst_0
    //   186: iload #6
    //   188: aload #10
    //   190: getfield second : Ljava/lang/Object;
    //   193: checkcast android/graphics/Rect
    //   196: invokevirtual getTextBounds : (Ljava/lang/String;IILandroid/graphics/Rect;)V
    //   199: aload #10
    //   201: getfield first : Ljava/lang/Object;
    //   204: checkcast android/graphics/Rect
    //   207: aload #10
    //   209: getfield second : Ljava/lang/Object;
    //   212: invokevirtual equals : (Ljava/lang/Object;)Z
    //   215: ifne -> 224
    //   218: iconst_1
    //   219: istore #8
    //   221: iload #8
    //   223: ireturn
    //   224: iconst_0
    //   225: istore #8
    //   227: goto -> 221
  }
  
  private static Pair<Rect, Rect> obtainEmptyRects() {
    Pair<Rect, Rect> pair = sRectThreadLocal.get();
    if (pair == null) {
      pair = new Pair(new Rect(), new Rect());
      sRectThreadLocal.set(pair);
      return pair;
    } 
    ((Rect)pair.first).setEmpty();
    ((Rect)pair.second).setEmpty();
    return pair;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Champions Cricket-dex2jar.jar!\android\support\v4\graphics\PaintCompatApi14.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */