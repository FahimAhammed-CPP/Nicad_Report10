package android.support.v4.graphics;

import android.content.Context;
import android.graphics.Typeface;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.annotation.RestrictTo;
import android.support.v4.provider.FontsContractCompat;
import android.system.ErrnoException;
import android.system.Os;
import android.system.OsConstants;
import java.io.File;

@RequiresApi(21)
@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
class TypefaceCompatApi21Impl extends TypefaceCompatBaseImpl {
  private static final String TAG = "TypefaceCompatApi21Impl";
  
  private File getFile(ParcelFileDescriptor paramParcelFileDescriptor) {
    try {
      String str = Os.readlink("/proc/self/fd/" + paramParcelFileDescriptor.getFd());
      return OsConstants.S_ISREG((Os.stat(str)).st_mode) ? new File(str) : null;
    } catch (ErrnoException errnoException) {
      return null;
    } 
  }
  
  public Typeface createFromFontInfo(Context paramContext, CancellationSignal paramCancellationSignal, @NonNull FontsContractCompat.FontInfo[] paramArrayOfFontInfo, int paramInt) {
    // Byte code:
    //   0: aload_3
    //   1: arraylength
    //   2: iconst_1
    //   3: if_icmpge -> 8
    //   6: aconst_null
    //   7: areturn
    //   8: aload_0
    //   9: aload_3
    //   10: iload #4
    //   12: invokevirtual findBestInfo : ([Landroid/support/v4/provider/FontsContractCompat$FontInfo;I)Landroid/support/v4/provider/FontsContractCompat$FontInfo;
    //   15: astore_3
    //   16: aload_1
    //   17: invokevirtual getContentResolver : ()Landroid/content/ContentResolver;
    //   20: astore #5
    //   22: aload #5
    //   24: aload_3
    //   25: invokevirtual getUri : ()Landroid/net/Uri;
    //   28: ldc 'r'
    //   30: aload_2
    //   31: invokevirtual openFileDescriptor : (Landroid/net/Uri;Ljava/lang/String;Landroid/os/CancellationSignal;)Landroid/os/ParcelFileDescriptor;
    //   34: astore_3
    //   35: aload_0
    //   36: aload_3
    //   37: invokespecial getFile : (Landroid/os/ParcelFileDescriptor;)Ljava/io/File;
    //   40: astore_2
    //   41: aload_2
    //   42: ifnull -> 52
    //   45: aload_2
    //   46: invokevirtual canRead : ()Z
    //   49: ifne -> 200
    //   52: new java/io/FileInputStream
    //   55: dup
    //   56: aload_3
    //   57: invokevirtual getFileDescriptor : ()Ljava/io/FileDescriptor;
    //   60: invokespecial <init> : (Ljava/io/FileDescriptor;)V
    //   63: astore #5
    //   65: aload_0
    //   66: aload_1
    //   67: aload #5
    //   69: invokespecial createFromInputStream : (Landroid/content/Context;Ljava/io/InputStream;)Landroid/graphics/Typeface;
    //   72: astore_1
    //   73: aload #5
    //   75: ifnull -> 87
    //   78: iconst_0
    //   79: ifeq -> 131
    //   82: aload #5
    //   84: invokevirtual close : ()V
    //   87: aload_3
    //   88: ifnull -> 99
    //   91: iconst_0
    //   92: ifeq -> 154
    //   95: aload_3
    //   96: invokevirtual close : ()V
    //   99: aload_1
    //   100: areturn
    //   101: astore_1
    //   102: new java/lang/NullPointerException
    //   105: dup
    //   106: invokespecial <init> : ()V
    //   109: athrow
    //   110: astore_2
    //   111: aload_2
    //   112: athrow
    //   113: astore_1
    //   114: aload_3
    //   115: ifnull -> 126
    //   118: aload_2
    //   119: ifnull -> 244
    //   122: aload_3
    //   123: invokevirtual close : ()V
    //   126: aload_1
    //   127: athrow
    //   128: astore_1
    //   129: aconst_null
    //   130: areturn
    //   131: aload #5
    //   133: invokevirtual close : ()V
    //   136: goto -> 87
    //   139: astore_1
    //   140: aconst_null
    //   141: astore_2
    //   142: goto -> 114
    //   145: astore_1
    //   146: new java/lang/NullPointerException
    //   149: dup
    //   150: invokespecial <init> : ()V
    //   153: athrow
    //   154: aload_3
    //   155: invokevirtual close : ()V
    //   158: goto -> 99
    //   161: astore_2
    //   162: aload_2
    //   163: athrow
    //   164: astore_1
    //   165: aload #5
    //   167: ifnull -> 179
    //   170: aload_2
    //   171: ifnull -> 192
    //   174: aload #5
    //   176: invokevirtual close : ()V
    //   179: aload_1
    //   180: athrow
    //   181: astore #5
    //   183: aload_2
    //   184: aload #5
    //   186: invokevirtual addSuppressed : (Ljava/lang/Throwable;)V
    //   189: goto -> 179
    //   192: aload #5
    //   194: invokevirtual close : ()V
    //   197: goto -> 179
    //   200: aload_2
    //   201: invokestatic createFromFile : (Ljava/io/File;)Landroid/graphics/Typeface;
    //   204: astore_1
    //   205: aload_3
    //   206: ifnull -> 217
    //   209: iconst_0
    //   210: ifeq -> 228
    //   213: aload_3
    //   214: invokevirtual close : ()V
    //   217: aload_1
    //   218: areturn
    //   219: astore_1
    //   220: new java/lang/NullPointerException
    //   223: dup
    //   224: invokespecial <init> : ()V
    //   227: athrow
    //   228: aload_3
    //   229: invokevirtual close : ()V
    //   232: goto -> 217
    //   235: astore_3
    //   236: aload_2
    //   237: aload_3
    //   238: invokevirtual addSuppressed : (Ljava/lang/Throwable;)V
    //   241: goto -> 126
    //   244: aload_3
    //   245: invokevirtual close : ()V
    //   248: goto -> 126
    //   251: astore_1
    //   252: aconst_null
    //   253: astore_2
    //   254: goto -> 165
    // Exception table:
    //   from	to	target	type
    //   22	35	128	java/io/IOException
    //   35	41	110	java/lang/Throwable
    //   35	41	139	finally
    //   45	52	110	java/lang/Throwable
    //   45	52	139	finally
    //   52	65	110	java/lang/Throwable
    //   52	65	139	finally
    //   65	73	161	java/lang/Throwable
    //   65	73	251	finally
    //   82	87	101	java/lang/Throwable
    //   82	87	139	finally
    //   95	99	145	java/lang/Throwable
    //   95	99	128	java/io/IOException
    //   102	110	110	java/lang/Throwable
    //   102	110	139	finally
    //   111	113	113	finally
    //   122	126	235	java/lang/Throwable
    //   122	126	128	java/io/IOException
    //   126	128	128	java/io/IOException
    //   131	136	110	java/lang/Throwable
    //   131	136	139	finally
    //   146	154	128	java/io/IOException
    //   154	158	128	java/io/IOException
    //   162	164	164	finally
    //   174	179	181	java/lang/Throwable
    //   174	179	139	finally
    //   179	181	110	java/lang/Throwable
    //   179	181	139	finally
    //   183	189	110	java/lang/Throwable
    //   183	189	139	finally
    //   192	197	110	java/lang/Throwable
    //   192	197	139	finally
    //   200	205	110	java/lang/Throwable
    //   200	205	139	finally
    //   213	217	219	java/lang/Throwable
    //   213	217	128	java/io/IOException
    //   220	228	128	java/io/IOException
    //   228	232	128	java/io/IOException
    //   236	241	128	java/io/IOException
    //   244	248	128	java/io/IOException
  }
}


/* Location:              C:\soft\dex2jar-2.0\Champions Cricket-dex2jar.jar!\android\support\v4\graphics\TypefaceCompatApi21Impl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */