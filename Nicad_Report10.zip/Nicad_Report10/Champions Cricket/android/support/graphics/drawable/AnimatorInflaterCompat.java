package android.support.graphics.drawable;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.animation.AnimatorSet;
import android.animation.Keyframe;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.TimeInterpolator;
import android.animation.TypeEvaluator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.os.Build;
import android.support.annotation.AnimatorRes;
import android.support.annotation.RestrictTo;
import android.support.v4.content.res.TypedArrayUtils;
import android.support.v4.graphics.PathParser;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.util.Xml;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public class AnimatorInflaterCompat {
  private static final boolean DBG_ANIMATOR_INFLATER = false;
  
  private static final int MAX_NUM_POINTS = 100;
  
  private static final String TAG = "AnimatorInflater";
  
  private static final int TOGETHER = 0;
  
  private static final int VALUE_TYPE_COLOR = 3;
  
  private static final int VALUE_TYPE_FLOAT = 0;
  
  private static final int VALUE_TYPE_INT = 1;
  
  private static final int VALUE_TYPE_PATH = 2;
  
  private static final int VALUE_TYPE_UNDEFINED = 4;
  
  private static Animator createAnimatorFromXml(Context paramContext, Resources paramResources, Resources.Theme paramTheme, XmlPullParser paramXmlPullParser, float paramFloat) throws XmlPullParserException, IOException {
    return createAnimatorFromXml(paramContext, paramResources, paramTheme, paramXmlPullParser, Xml.asAttributeSet(paramXmlPullParser), null, 0, paramFloat);
  }
  
  private static Animator createAnimatorFromXml(Context paramContext, Resources paramResources, Resources.Theme paramTheme, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, AnimatorSet paramAnimatorSet, int paramInt, float paramFloat) throws XmlPullParserException, IOException {
    Animator[] arrayOfAnimator;
    TypedArray typedArray = null;
    ArrayList<TypedArray> arrayList = null;
    int i = paramXmlPullParser.getDepth();
    while (true) {
      int j = paramXmlPullParser.next();
      if ((j != 3 || paramXmlPullParser.getDepth() > i) && j != 1) {
        if (j == 2) {
          ObjectAnimator objectAnimator;
          TypedArray typedArray1;
          String str = paramXmlPullParser.getName();
          j = 0;
          if (str.equals("objectAnimator")) {
            objectAnimator = loadObjectAnimator(paramContext, paramResources, paramTheme, paramAttributeSet, paramFloat, paramXmlPullParser);
          } else {
            ValueAnimator valueAnimator;
            if (objectAnimator.equals("animator")) {
              valueAnimator = loadAnimator(paramContext, paramResources, paramTheme, paramAttributeSet, null, paramFloat, paramXmlPullParser);
            } else {
              AnimatorSet animatorSet;
              if (valueAnimator.equals("set")) {
                animatorSet = new AnimatorSet();
                typedArray = TypedArrayUtils.obtainAttributes(paramResources, paramTheme, paramAttributeSet, AndroidResources.STYLEABLE_ANIMATOR_SET);
                int k = TypedArrayUtils.getNamedInt(typedArray, paramXmlPullParser, "ordering", 0, 0);
                createAnimatorFromXml(paramContext, paramResources, paramTheme, paramXmlPullParser, paramAttributeSet, animatorSet, k, paramFloat);
                typedArray.recycle();
              } else if (animatorSet.equals("propertyValuesHolder")) {
                PropertyValuesHolder[] arrayOfPropertyValuesHolder = loadValues(paramContext, paramResources, paramTheme, paramXmlPullParser, Xml.asAttributeSet(paramXmlPullParser));
                if (arrayOfPropertyValuesHolder != null && typedArray != null && typedArray instanceof ValueAnimator)
                  ((ValueAnimator)typedArray).setValues(arrayOfPropertyValuesHolder); 
                j = 1;
                typedArray1 = typedArray;
              } else {
                throw new RuntimeException("Unknown animator name: " + paramXmlPullParser.getName());
              } 
            } 
          } 
          typedArray = typedArray1;
          if (paramAnimatorSet != null) {
            typedArray = typedArray1;
            if (j == 0) {
              ArrayList<TypedArray> arrayList1 = arrayList;
              if (arrayList == null)
                arrayList1 = new ArrayList(); 
              arrayList1.add(typedArray1);
              typedArray = typedArray1;
              arrayList = arrayList1;
            } 
          } 
        } 
        continue;
      } 
      break;
    } 
    if (paramAnimatorSet != null && arrayList != null) {
      arrayOfAnimator = new Animator[arrayList.size()];
      int j = 0;
      Iterator<TypedArray> iterator = arrayList.iterator();
      while (iterator.hasNext()) {
        arrayOfAnimator[j] = (Animator)iterator.next();
        j++;
      } 
      if (paramInt == 0) {
        paramAnimatorSet.playTogether(arrayOfAnimator);
        return (Animator)typedArray;
      } 
    } else {
      return (Animator)typedArray;
    } 
    paramAnimatorSet.playSequentially(arrayOfAnimator);
    return (Animator)typedArray;
  }
  
  private static Keyframe createNewKeyframe(Keyframe paramKeyframe, float paramFloat) {
    return (paramKeyframe.getType() == float.class) ? Keyframe.ofFloat(paramFloat) : ((paramKeyframe.getType() == int.class) ? Keyframe.ofInt(paramFloat) : Keyframe.ofObject(paramFloat));
  }
  
  private static void distributeKeyframes(Keyframe[] paramArrayOfKeyframe, float paramFloat, int paramInt1, int paramInt2) {
    paramFloat /= (paramInt2 - paramInt1 + 2);
    while (paramInt1 <= paramInt2) {
      paramArrayOfKeyframe[paramInt1].setFraction(paramArrayOfKeyframe[paramInt1 - 1].getFraction() + paramFloat);
      paramInt1++;
    } 
  }
  
  private static void dumpKeyframes(Object[] paramArrayOfObject, String paramString) {
    if (paramArrayOfObject != null && paramArrayOfObject.length != 0) {
      Log.d("AnimatorInflater", paramString);
      int j = paramArrayOfObject.length;
      int i = 0;
      while (true) {
        if (i < j) {
          Float float_;
          Object object;
          Keyframe keyframe = (Keyframe)paramArrayOfObject[i];
          StringBuilder stringBuilder = (new StringBuilder()).append("Keyframe ").append(i).append(": fraction ");
          if (keyframe.getFraction() < 0.0F) {
            paramString = "null";
          } else {
            float_ = Float.valueOf(keyframe.getFraction());
          } 
          stringBuilder = stringBuilder.append(float_).append(", ").append(", value : ");
          if (keyframe.hasValue()) {
            object = keyframe.getValue();
          } else {
            object = "null";
          } 
          Log.d("AnimatorInflater", stringBuilder.append(object).toString());
          i++;
          continue;
        } 
        return;
      } 
    } 
  }
  
  private static PropertyValuesHolder getPVH(TypedArray paramTypedArray, int paramInt1, int paramInt2, int paramInt3, String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: iload_2
    //   2: invokevirtual peekValue : (I)Landroid/util/TypedValue;
    //   5: astore #12
    //   7: aload #12
    //   9: ifnull -> 220
    //   12: iconst_1
    //   13: istore #8
    //   15: iload #8
    //   17: ifeq -> 226
    //   20: aload #12
    //   22: getfield type : I
    //   25: istore #10
    //   27: aload_0
    //   28: iload_3
    //   29: invokevirtual peekValue : (I)Landroid/util/TypedValue;
    //   32: astore #12
    //   34: aload #12
    //   36: ifnull -> 232
    //   39: iconst_1
    //   40: istore #9
    //   42: iload #9
    //   44: ifeq -> 238
    //   47: aload #12
    //   49: getfield type : I
    //   52: istore #11
    //   54: iload_1
    //   55: istore #7
    //   57: iload_1
    //   58: iconst_4
    //   59: if_icmpne -> 91
    //   62: iload #8
    //   64: ifeq -> 75
    //   67: iload #10
    //   69: invokestatic isColorType : (I)Z
    //   72: ifne -> 88
    //   75: iload #9
    //   77: ifeq -> 244
    //   80: iload #11
    //   82: invokestatic isColorType : (I)Z
    //   85: ifeq -> 244
    //   88: iconst_3
    //   89: istore #7
    //   91: iload #7
    //   93: ifne -> 250
    //   96: iconst_1
    //   97: istore_1
    //   98: aconst_null
    //   99: astore #14
    //   101: aconst_null
    //   102: astore #12
    //   104: iload #7
    //   106: iconst_2
    //   107: if_icmpne -> 325
    //   110: aload_0
    //   111: iload_2
    //   112: invokevirtual getString : (I)Ljava/lang/String;
    //   115: astore #13
    //   117: aload_0
    //   118: iload_3
    //   119: invokevirtual getString : (I)Ljava/lang/String;
    //   122: astore #14
    //   124: aload #13
    //   126: invokestatic createNodesFromPathData : (Ljava/lang/String;)[Landroid/support/v4/graphics/PathParser$PathDataNode;
    //   129: astore #15
    //   131: aload #14
    //   133: invokestatic createNodesFromPathData : (Ljava/lang/String;)[Landroid/support/v4/graphics/PathParser$PathDataNode;
    //   136: astore #16
    //   138: aload #15
    //   140: ifnonnull -> 151
    //   143: aload #12
    //   145: astore_0
    //   146: aload #16
    //   148: ifnull -> 276
    //   151: aload #15
    //   153: ifnull -> 294
    //   156: new android/support/graphics/drawable/AnimatorInflaterCompat$PathDataEvaluator
    //   159: dup
    //   160: aconst_null
    //   161: invokespecial <init> : (Landroid/support/graphics/drawable/AnimatorInflaterCompat$1;)V
    //   164: astore_0
    //   165: aload #16
    //   167: ifnull -> 278
    //   170: aload #15
    //   172: aload #16
    //   174: invokestatic canMorph : ([Landroid/support/v4/graphics/PathParser$PathDataNode;[Landroid/support/v4/graphics/PathParser$PathDataNode;)Z
    //   177: ifne -> 255
    //   180: new android/view/InflateException
    //   183: dup
    //   184: new java/lang/StringBuilder
    //   187: dup
    //   188: invokespecial <init> : ()V
    //   191: ldc_w ' Can't morph from '
    //   194: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   197: aload #13
    //   199: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   202: ldc_w ' to '
    //   205: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   208: aload #14
    //   210: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   213: invokevirtual toString : ()Ljava/lang/String;
    //   216: invokespecial <init> : (Ljava/lang/String;)V
    //   219: athrow
    //   220: iconst_0
    //   221: istore #8
    //   223: goto -> 15
    //   226: iconst_0
    //   227: istore #10
    //   229: goto -> 27
    //   232: iconst_0
    //   233: istore #9
    //   235: goto -> 42
    //   238: iconst_0
    //   239: istore #11
    //   241: goto -> 54
    //   244: iconst_0
    //   245: istore #7
    //   247: goto -> 91
    //   250: iconst_0
    //   251: istore_1
    //   252: goto -> 98
    //   255: aload #4
    //   257: aload_0
    //   258: iconst_2
    //   259: anewarray java/lang/Object
    //   262: dup
    //   263: iconst_0
    //   264: aload #15
    //   266: aastore
    //   267: dup
    //   268: iconst_1
    //   269: aload #16
    //   271: aastore
    //   272: invokestatic ofObject : (Ljava/lang/String;Landroid/animation/TypeEvaluator;[Ljava/lang/Object;)Landroid/animation/PropertyValuesHolder;
    //   275: astore_0
    //   276: aload_0
    //   277: areturn
    //   278: aload #4
    //   280: aload_0
    //   281: iconst_1
    //   282: anewarray java/lang/Object
    //   285: dup
    //   286: iconst_0
    //   287: aload #15
    //   289: aastore
    //   290: invokestatic ofObject : (Ljava/lang/String;Landroid/animation/TypeEvaluator;[Ljava/lang/Object;)Landroid/animation/PropertyValuesHolder;
    //   293: areturn
    //   294: aload #12
    //   296: astore_0
    //   297: aload #16
    //   299: ifnull -> 276
    //   302: aload #4
    //   304: new android/support/graphics/drawable/AnimatorInflaterCompat$PathDataEvaluator
    //   307: dup
    //   308: aconst_null
    //   309: invokespecial <init> : (Landroid/support/graphics/drawable/AnimatorInflaterCompat$1;)V
    //   312: iconst_1
    //   313: anewarray java/lang/Object
    //   316: dup
    //   317: iconst_0
    //   318: aload #16
    //   320: aastore
    //   321: invokestatic ofObject : (Ljava/lang/String;Landroid/animation/TypeEvaluator;[Ljava/lang/Object;)Landroid/animation/PropertyValuesHolder;
    //   324: areturn
    //   325: aconst_null
    //   326: astore #13
    //   328: iload #7
    //   330: iconst_3
    //   331: if_icmpne -> 339
    //   334: invokestatic getInstance : ()Landroid/support/graphics/drawable/ArgbEvaluator;
    //   337: astore #13
    //   339: iload_1
    //   340: ifeq -> 510
    //   343: iload #8
    //   345: ifeq -> 467
    //   348: iload #10
    //   350: iconst_5
    //   351: if_icmpne -> 427
    //   354: aload_0
    //   355: iload_2
    //   356: fconst_0
    //   357: invokevirtual getDimension : (IF)F
    //   360: fstore #5
    //   362: iload #9
    //   364: ifeq -> 449
    //   367: iload #11
    //   369: iconst_5
    //   370: if_icmpne -> 438
    //   373: aload_0
    //   374: iload_3
    //   375: fconst_0
    //   376: invokevirtual getDimension : (IF)F
    //   379: fstore #6
    //   381: aload #4
    //   383: iconst_2
    //   384: newarray float
    //   386: dup
    //   387: iconst_0
    //   388: fload #5
    //   390: fastore
    //   391: dup
    //   392: iconst_1
    //   393: fload #6
    //   395: fastore
    //   396: invokestatic ofFloat : (Ljava/lang/String;[F)Landroid/animation/PropertyValuesHolder;
    //   399: astore #12
    //   401: aload #12
    //   403: astore_0
    //   404: aload #12
    //   406: ifnull -> 276
    //   409: aload #12
    //   411: astore_0
    //   412: aload #13
    //   414: ifnull -> 276
    //   417: aload #12
    //   419: aload #13
    //   421: invokevirtual setEvaluator : (Landroid/animation/TypeEvaluator;)V
    //   424: aload #12
    //   426: areturn
    //   427: aload_0
    //   428: iload_2
    //   429: fconst_0
    //   430: invokevirtual getFloat : (IF)F
    //   433: fstore #5
    //   435: goto -> 362
    //   438: aload_0
    //   439: iload_3
    //   440: fconst_0
    //   441: invokevirtual getFloat : (IF)F
    //   444: fstore #6
    //   446: goto -> 381
    //   449: aload #4
    //   451: iconst_1
    //   452: newarray float
    //   454: dup
    //   455: iconst_0
    //   456: fload #5
    //   458: fastore
    //   459: invokestatic ofFloat : (Ljava/lang/String;[F)Landroid/animation/PropertyValuesHolder;
    //   462: astore #12
    //   464: goto -> 401
    //   467: iload #11
    //   469: iconst_5
    //   470: if_icmpne -> 499
    //   473: aload_0
    //   474: iload_3
    //   475: fconst_0
    //   476: invokevirtual getDimension : (IF)F
    //   479: fstore #5
    //   481: aload #4
    //   483: iconst_1
    //   484: newarray float
    //   486: dup
    //   487: iconst_0
    //   488: fload #5
    //   490: fastore
    //   491: invokestatic ofFloat : (Ljava/lang/String;[F)Landroid/animation/PropertyValuesHolder;
    //   494: astore #12
    //   496: goto -> 401
    //   499: aload_0
    //   500: iload_3
    //   501: fconst_0
    //   502: invokevirtual getFloat : (IF)F
    //   505: fstore #5
    //   507: goto -> 481
    //   510: iload #8
    //   512: ifeq -> 642
    //   515: iload #10
    //   517: iconst_5
    //   518: if_icmpne -> 569
    //   521: aload_0
    //   522: iload_2
    //   523: fconst_0
    //   524: invokevirtual getDimension : (IF)F
    //   527: f2i
    //   528: istore_1
    //   529: iload #9
    //   531: ifeq -> 625
    //   534: iload #11
    //   536: iconst_5
    //   537: if_icmpne -> 597
    //   540: aload_0
    //   541: iload_3
    //   542: fconst_0
    //   543: invokevirtual getDimension : (IF)F
    //   546: f2i
    //   547: istore_2
    //   548: aload #4
    //   550: iconst_2
    //   551: newarray int
    //   553: dup
    //   554: iconst_0
    //   555: iload_1
    //   556: iastore
    //   557: dup
    //   558: iconst_1
    //   559: iload_2
    //   560: iastore
    //   561: invokestatic ofInt : (Ljava/lang/String;[I)Landroid/animation/PropertyValuesHolder;
    //   564: astore #12
    //   566: goto -> 401
    //   569: iload #10
    //   571: invokestatic isColorType : (I)Z
    //   574: ifeq -> 587
    //   577: aload_0
    //   578: iload_2
    //   579: iconst_0
    //   580: invokevirtual getColor : (II)I
    //   583: istore_1
    //   584: goto -> 529
    //   587: aload_0
    //   588: iload_2
    //   589: iconst_0
    //   590: invokevirtual getInt : (II)I
    //   593: istore_1
    //   594: goto -> 529
    //   597: iload #11
    //   599: invokestatic isColorType : (I)Z
    //   602: ifeq -> 615
    //   605: aload_0
    //   606: iload_3
    //   607: iconst_0
    //   608: invokevirtual getColor : (II)I
    //   611: istore_2
    //   612: goto -> 548
    //   615: aload_0
    //   616: iload_3
    //   617: iconst_0
    //   618: invokevirtual getInt : (II)I
    //   621: istore_2
    //   622: goto -> 548
    //   625: aload #4
    //   627: iconst_1
    //   628: newarray int
    //   630: dup
    //   631: iconst_0
    //   632: iload_1
    //   633: iastore
    //   634: invokestatic ofInt : (Ljava/lang/String;[I)Landroid/animation/PropertyValuesHolder;
    //   637: astore #12
    //   639: goto -> 401
    //   642: aload #14
    //   644: astore #12
    //   646: iload #9
    //   648: ifeq -> 401
    //   651: iload #11
    //   653: iconst_5
    //   654: if_icmpne -> 682
    //   657: aload_0
    //   658: iload_3
    //   659: fconst_0
    //   660: invokevirtual getDimension : (IF)F
    //   663: f2i
    //   664: istore_1
    //   665: aload #4
    //   667: iconst_1
    //   668: newarray int
    //   670: dup
    //   671: iconst_0
    //   672: iload_1
    //   673: iastore
    //   674: invokestatic ofInt : (Ljava/lang/String;[I)Landroid/animation/PropertyValuesHolder;
    //   677: astore #12
    //   679: goto -> 401
    //   682: iload #11
    //   684: invokestatic isColorType : (I)Z
    //   687: ifeq -> 700
    //   690: aload_0
    //   691: iload_3
    //   692: iconst_0
    //   693: invokevirtual getColor : (II)I
    //   696: istore_1
    //   697: goto -> 665
    //   700: aload_0
    //   701: iload_3
    //   702: iconst_0
    //   703: invokevirtual getInt : (II)I
    //   706: istore_1
    //   707: goto -> 665
  }
  
  private static int inferValueTypeFromValues(TypedArray paramTypedArray, int paramInt1, int paramInt2) {
    boolean bool;
    int i = 1;
    TypedValue typedValue2 = paramTypedArray.peekValue(paramInt1);
    if (typedValue2 != null) {
      paramInt1 = 1;
    } else {
      paramInt1 = 0;
    } 
    if (paramInt1 != 0) {
      bool = typedValue2.type;
    } else {
      bool = false;
    } 
    TypedValue typedValue1 = paramTypedArray.peekValue(paramInt2);
    if (typedValue1 != null) {
      paramInt2 = i;
    } else {
      paramInt2 = 0;
    } 
    if (paramInt2 != 0) {
      i = typedValue1.type;
    } else {
      i = 0;
    } 
    return ((paramInt1 != 0 && isColorType(bool)) || (paramInt2 != 0 && isColorType(i))) ? 3 : 0;
  }
  
  private static int inferValueTypeOfKeyframe(Resources paramResources, Resources.Theme paramTheme, AttributeSet paramAttributeSet, XmlPullParser paramXmlPullParser) {
    byte b = 0;
    TypedArray typedArray = TypedArrayUtils.obtainAttributes(paramResources, paramTheme, paramAttributeSet, AndroidResources.STYLEABLE_KEYFRAME);
    TypedValue typedValue = TypedArrayUtils.peekNamedValue(typedArray, paramXmlPullParser, "value", 0);
    if (typedValue != null)
      b = 1; 
    if (b && isColorType(typedValue.type)) {
      b = 3;
      typedArray.recycle();
      return b;
    } 
    b = 0;
    typedArray.recycle();
    return b;
  }
  
  private static boolean isColorType(int paramInt) {
    return (paramInt >= 28 && paramInt <= 31);
  }
  
  public static Animator loadAnimator(Context paramContext, @AnimatorRes int paramInt) throws Resources.NotFoundException {
    return (Build.VERSION.SDK_INT >= 24) ? AnimatorInflater.loadAnimator(paramContext, paramInt) : loadAnimator(paramContext, paramContext.getResources(), paramContext.getTheme(), paramInt);
  }
  
  public static Animator loadAnimator(Context paramContext, Resources paramResources, Resources.Theme paramTheme, @AnimatorRes int paramInt) throws Resources.NotFoundException {
    return loadAnimator(paramContext, paramResources, paramTheme, paramInt, 1.0F);
  }
  
  public static Animator loadAnimator(Context paramContext, Resources paramResources, Resources.Theme paramTheme, @AnimatorRes int paramInt, float paramFloat) throws Resources.NotFoundException {
    XmlResourceParser xmlResourceParser1 = null;
    XmlResourceParser xmlResourceParser3 = null;
    XmlResourceParser xmlResourceParser2 = null;
    try {
      XmlResourceParser xmlResourceParser = paramResources.getAnimation(paramInt);
      xmlResourceParser2 = xmlResourceParser;
      xmlResourceParser1 = xmlResourceParser;
      xmlResourceParser3 = xmlResourceParser;
      return createAnimatorFromXml(paramContext, paramResources, paramTheme, (XmlPullParser)xmlResourceParser, paramFloat);
    } catch (XmlPullParserException xmlPullParserException) {
      xmlResourceParser1 = xmlResourceParser2;
      Resources.NotFoundException notFoundException = new Resources.NotFoundException("Can't load animation resource ID #0x" + Integer.toHexString(paramInt));
      xmlResourceParser1 = xmlResourceParser2;
      notFoundException.initCause((Throwable)xmlPullParserException);
      xmlResourceParser1 = xmlResourceParser2;
      throw notFoundException;
    } catch (IOException iOException) {
      xmlResourceParser1 = xmlResourceParser3;
      Resources.NotFoundException notFoundException = new Resources.NotFoundException("Can't load animation resource ID #0x" + Integer.toHexString(paramInt));
      xmlResourceParser1 = xmlResourceParser3;
      notFoundException.initCause(iOException);
      xmlResourceParser1 = xmlResourceParser3;
      throw notFoundException;
    } finally {
      if (xmlResourceParser1 != null)
        xmlResourceParser1.close(); 
    } 
  }
  
  private static ValueAnimator loadAnimator(Context paramContext, Resources paramResources, Resources.Theme paramTheme, AttributeSet paramAttributeSet, ValueAnimator paramValueAnimator, float paramFloat, XmlPullParser paramXmlPullParser) throws Resources.NotFoundException {
    TypedArray typedArray2 = TypedArrayUtils.obtainAttributes(paramResources, paramTheme, paramAttributeSet, AndroidResources.STYLEABLE_ANIMATOR);
    TypedArray typedArray1 = TypedArrayUtils.obtainAttributes(paramResources, paramTheme, paramAttributeSet, AndroidResources.STYLEABLE_PROPERTY_ANIMATOR);
    ValueAnimator valueAnimator = paramValueAnimator;
    if (paramValueAnimator == null)
      valueAnimator = new ValueAnimator(); 
    parseAnimatorFromTypeArray(valueAnimator, typedArray2, typedArray1, paramFloat, paramXmlPullParser);
    int i = TypedArrayUtils.getNamedResourceId(typedArray2, paramXmlPullParser, "interpolator", 0, 0);
    if (i > 0)
      valueAnimator.setInterpolator((TimeInterpolator)AnimationUtilsCompat.loadInterpolator(paramContext, i)); 
    typedArray2.recycle();
    if (typedArray1 != null)
      typedArray1.recycle(); 
    return valueAnimator;
  }
  
  private static Keyframe loadKeyframe(Context paramContext, Resources paramResources, Resources.Theme paramTheme, AttributeSet paramAttributeSet, int paramInt, XmlPullParser paramXmlPullParser) throws XmlPullParserException, IOException {
    boolean bool;
    TypedArray typedArray = TypedArrayUtils.obtainAttributes(paramResources, paramTheme, paramAttributeSet, AndroidResources.STYLEABLE_KEYFRAME);
    paramTheme = null;
    float f = TypedArrayUtils.getNamedFloat(typedArray, paramXmlPullParser, "fraction", 3, -1.0F);
    TypedValue typedValue = TypedArrayUtils.peekNamedValue(typedArray, paramXmlPullParser, "value", 0);
    if (typedValue != null) {
      bool = true;
    } else {
      bool = false;
    } 
    int i = paramInt;
    if (paramInt == 4)
      if (bool && isColorType(typedValue.type)) {
        i = 3;
      } else {
        i = 0;
      }  
    if (bool) {
      Resources.Theme theme = paramTheme;
      switch (i) {
        default:
          theme = paramTheme;
        case 2:
          paramInt = TypedArrayUtils.getNamedResourceId(typedArray, paramXmlPullParser, "interpolator", 1, 0);
          if (paramInt > 0)
            theme.setInterpolator((TimeInterpolator)AnimationUtilsCompat.loadInterpolator(paramContext, paramInt)); 
          typedArray.recycle();
          return (Keyframe)theme;
        case 0:
          keyframe1 = Keyframe.ofFloat(f, TypedArrayUtils.getNamedFloat(typedArray, paramXmlPullParser, "value", 0, 0.0F));
        case 1:
        case 3:
          break;
      } 
      Keyframe keyframe1 = Keyframe.ofInt(f, TypedArrayUtils.getNamedInt(typedArray, paramXmlPullParser, "value", 0, 0));
    } 
    if (i == 0)
      Keyframe keyframe1 = Keyframe.ofFloat(f); 
    Keyframe keyframe = Keyframe.ofInt(f);
  }
  
  private static ObjectAnimator loadObjectAnimator(Context paramContext, Resources paramResources, Resources.Theme paramTheme, AttributeSet paramAttributeSet, float paramFloat, XmlPullParser paramXmlPullParser) throws Resources.NotFoundException {
    ObjectAnimator objectAnimator = new ObjectAnimator();
    loadAnimator(paramContext, paramResources, paramTheme, paramAttributeSet, (ValueAnimator)objectAnimator, paramFloat, paramXmlPullParser);
    return objectAnimator;
  }
  
  private static PropertyValuesHolder loadPvh(Context paramContext, Resources paramResources, Resources.Theme paramTheme, XmlPullParser paramXmlPullParser, String paramString, int paramInt) throws XmlPullParserException, IOException {
    PropertyValuesHolder propertyValuesHolder;
    Context context = null;
    ArrayList<Keyframe> arrayList = null;
    int i = paramInt;
    while (true) {
      paramInt = paramXmlPullParser.next();
      if (paramInt != 3 && paramInt != 1) {
        if (paramXmlPullParser.getName().equals("keyframe")) {
          paramInt = i;
          if (i == 4)
            paramInt = inferValueTypeOfKeyframe(paramResources, paramTheme, Xml.asAttributeSet(paramXmlPullParser), paramXmlPullParser); 
          Keyframe keyframe = loadKeyframe(paramContext, paramResources, paramTheme, Xml.asAttributeSet(paramXmlPullParser), paramInt, paramXmlPullParser);
          ArrayList<Keyframe> arrayList1 = arrayList;
          if (keyframe != null) {
            arrayList1 = arrayList;
            if (arrayList == null)
              arrayList1 = new ArrayList(); 
            arrayList1.add(keyframe);
          } 
          paramXmlPullParser.next();
          arrayList = arrayList1;
          i = paramInt;
        } 
        continue;
      } 
      break;
    } 
    paramContext = context;
    if (arrayList != null) {
      int j = arrayList.size();
      paramContext = context;
      if (j > 0) {
        Keyframe keyframe1 = arrayList.get(0);
        Keyframe keyframe2 = arrayList.get(j - 1);
        float f = keyframe2.getFraction();
        paramInt = j;
        if (f < 1.0F)
          if (f < 0.0F) {
            keyframe2.setFraction(1.0F);
            paramInt = j;
          } else {
            arrayList.add(arrayList.size(), createNewKeyframe(keyframe2, 1.0F));
            paramInt = j + 1;
          }  
        f = keyframe1.getFraction();
        int k = paramInt;
        if (f != 0.0F)
          if (f < 0.0F) {
            keyframe1.setFraction(0.0F);
            k = paramInt;
          } else {
            arrayList.add(0, createNewKeyframe(keyframe1, 0.0F));
            k = paramInt + 1;
          }  
        Keyframe[] arrayOfKeyframe = new Keyframe[k];
        arrayList.toArray(arrayOfKeyframe);
        paramInt = 0;
        label57: while (paramInt < k) {
          keyframe2 = arrayOfKeyframe[paramInt];
          if (keyframe2.getFraction() < 0.0F) {
            if (paramInt == 0) {
              keyframe2.setFraction(0.0F);
              continue;
            } 
            if (paramInt == k - 1) {
              keyframe2.setFraction(1.0F);
              continue;
            } 
            int m = paramInt;
            for (j = paramInt + 1;; j++) {
              if (j >= k - 1 || arrayOfKeyframe[j].getFraction() >= 0.0F) {
                distributeKeyframes(arrayOfKeyframe, arrayOfKeyframe[m + 1].getFraction() - arrayOfKeyframe[paramInt - 1].getFraction(), paramInt, m);
                paramInt++;
                continue label57;
              } 
              m = j;
            } 
          } 
          continue;
        } 
        PropertyValuesHolder propertyValuesHolder1 = PropertyValuesHolder.ofKeyframe(paramString, arrayOfKeyframe);
        propertyValuesHolder = propertyValuesHolder1;
        if (i == 3) {
          propertyValuesHolder1.setEvaluator(ArgbEvaluator.getInstance());
          propertyValuesHolder = propertyValuesHolder1;
        } 
      } 
    } 
    return propertyValuesHolder;
  }
  
  private static PropertyValuesHolder[] loadValues(Context paramContext, Resources paramResources, Resources.Theme paramTheme, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet) throws XmlPullParserException, IOException {
    PropertyValuesHolder[] arrayOfPropertyValuesHolder;
    ArrayList<PropertyValuesHolder> arrayList;
    PropertyValuesHolder propertyValuesHolder = null;
    while (true) {
      int i = paramXmlPullParser.getEventType();
      if (i != 3 && i != 1) {
        ArrayList<PropertyValuesHolder> arrayList1;
        if (i != 2) {
          paramXmlPullParser.next();
          continue;
        } 
        PropertyValuesHolder propertyValuesHolder1 = propertyValuesHolder;
        if (paramXmlPullParser.getName().equals("propertyValuesHolder")) {
          TypedArray typedArray = TypedArrayUtils.obtainAttributes(paramResources, paramTheme, paramAttributeSet, AndroidResources.STYLEABLE_PROPERTY_VALUES_HOLDER);
          String str = TypedArrayUtils.getNamedString(typedArray, paramXmlPullParser, "propertyName", 3);
          i = TypedArrayUtils.getNamedInt(typedArray, paramXmlPullParser, "valueType", 2, 4);
          propertyValuesHolder1 = loadPvh(paramContext, paramResources, paramTheme, paramXmlPullParser, str, i);
          PropertyValuesHolder propertyValuesHolder2 = propertyValuesHolder1;
          if (propertyValuesHolder1 == null)
            propertyValuesHolder2 = getPVH(typedArray, i, 0, 1, str); 
          propertyValuesHolder1 = propertyValuesHolder;
          if (propertyValuesHolder2 != null) {
            propertyValuesHolder1 = propertyValuesHolder;
            if (propertyValuesHolder == null)
              arrayList1 = new ArrayList(); 
            arrayList1.add(propertyValuesHolder2);
          } 
          typedArray.recycle();
        } 
        paramXmlPullParser.next();
        arrayList = arrayList1;
        continue;
      } 
      break;
    } 
    paramContext = null;
    if (arrayList != null) {
      int j = arrayList.size();
      PropertyValuesHolder[] arrayOfPropertyValuesHolder1 = new PropertyValuesHolder[j];
      int i = 0;
      while (true) {
        arrayOfPropertyValuesHolder = arrayOfPropertyValuesHolder1;
        if (i < j) {
          arrayOfPropertyValuesHolder1[i] = arrayList.get(i);
          i++;
          continue;
        } 
        break;
      } 
    } 
    return arrayOfPropertyValuesHolder;
  }
  
  private static void parseAnimatorFromTypeArray(ValueAnimator paramValueAnimator, TypedArray paramTypedArray1, TypedArray paramTypedArray2, float paramFloat, XmlPullParser paramXmlPullParser) {
    long l1 = TypedArrayUtils.getNamedInt(paramTypedArray1, paramXmlPullParser, "duration", 1, 300);
    long l2 = TypedArrayUtils.getNamedInt(paramTypedArray1, paramXmlPullParser, "startOffset", 2, 0);
    int i = TypedArrayUtils.getNamedInt(paramTypedArray1, paramXmlPullParser, "valueType", 7, 4);
    int j = i;
    if (TypedArrayUtils.hasAttribute(paramXmlPullParser, "valueFrom")) {
      j = i;
      if (TypedArrayUtils.hasAttribute(paramXmlPullParser, "valueTo")) {
        int k = i;
        if (i == 4)
          k = inferValueTypeFromValues(paramTypedArray1, 5, 6); 
        PropertyValuesHolder propertyValuesHolder = getPVH(paramTypedArray1, k, 5, 6, "");
        j = k;
        if (propertyValuesHolder != null) {
          paramValueAnimator.setValues(new PropertyValuesHolder[] { propertyValuesHolder });
          j = k;
        } 
      } 
    } 
    paramValueAnimator.setDuration(l1);
    paramValueAnimator.setStartDelay(l2);
    paramValueAnimator.setRepeatCount(TypedArrayUtils.getNamedInt(paramTypedArray1, paramXmlPullParser, "repeatCount", 3, 0));
    paramValueAnimator.setRepeatMode(TypedArrayUtils.getNamedInt(paramTypedArray1, paramXmlPullParser, "repeatMode", 4, 1));
    if (paramTypedArray2 != null)
      setupObjectAnimator(paramValueAnimator, paramTypedArray2, j, paramFloat, paramXmlPullParser); 
  }
  
  private static void setupObjectAnimator(ValueAnimator paramValueAnimator, TypedArray paramTypedArray, int paramInt, float paramFloat, XmlPullParser paramXmlPullParser) {
    // Byte code:
    //   0: aload_0
    //   1: checkcast android/animation/ObjectAnimator
    //   4: astore_0
    //   5: aload_1
    //   6: aload #4
    //   8: ldc_w 'pathData'
    //   11: iconst_1
    //   12: invokestatic getNamedString : (Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;I)Ljava/lang/String;
    //   15: astore #5
    //   17: aload #5
    //   19: ifnull -> 116
    //   22: aload_1
    //   23: aload #4
    //   25: ldc_w 'propertyXName'
    //   28: iconst_2
    //   29: invokestatic getNamedString : (Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;I)Ljava/lang/String;
    //   32: astore #6
    //   34: aload_1
    //   35: aload #4
    //   37: ldc_w 'propertyYName'
    //   40: iconst_3
    //   41: invokestatic getNamedString : (Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;I)Ljava/lang/String;
    //   44: astore #4
    //   46: iload_2
    //   47: iconst_2
    //   48: if_icmpeq -> 56
    //   51: iload_2
    //   52: iconst_4
    //   53: if_icmpne -> 56
    //   56: aload #6
    //   58: ifnonnull -> 97
    //   61: aload #4
    //   63: ifnonnull -> 97
    //   66: new android/view/InflateException
    //   69: dup
    //   70: new java/lang/StringBuilder
    //   73: dup
    //   74: invokespecial <init> : ()V
    //   77: aload_1
    //   78: invokevirtual getPositionDescription : ()Ljava/lang/String;
    //   81: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   84: ldc_w ' propertyXName or propertyYName is needed for PathData'
    //   87: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   90: invokevirtual toString : ()Ljava/lang/String;
    //   93: invokespecial <init> : (Ljava/lang/String;)V
    //   96: athrow
    //   97: aload #5
    //   99: invokestatic createPathFromPathData : (Ljava/lang/String;)Landroid/graphics/Path;
    //   102: aload_0
    //   103: ldc_w 0.5
    //   106: fload_3
    //   107: fmul
    //   108: aload #6
    //   110: aload #4
    //   112: invokestatic setupPathMotion : (Landroid/graphics/Path;Landroid/animation/ObjectAnimator;FLjava/lang/String;Ljava/lang/String;)V
    //   115: return
    //   116: aload_0
    //   117: aload_1
    //   118: aload #4
    //   120: ldc_w 'propertyName'
    //   123: iconst_0
    //   124: invokestatic getNamedString : (Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;I)Ljava/lang/String;
    //   127: invokevirtual setPropertyName : (Ljava/lang/String;)V
    //   130: return
  }
  
  private static void setupPathMotion(Path paramPath, ObjectAnimator paramObjectAnimator, float paramFloat, String paramString1, String paramString2) {
    PathMeasure pathMeasure = new PathMeasure(paramPath, false);
    float f = 0.0F;
    ArrayList<Float> arrayList = new ArrayList();
    arrayList.add(Float.valueOf(0.0F));
    while (true) {
      float f1 = f + pathMeasure.getLength();
      arrayList.add(Float.valueOf(f1));
      f = f1;
      if (!pathMeasure.nextContour()) {
        PropertyValuesHolder propertyValuesHolder1;
        PropertyValuesHolder propertyValuesHolder2;
        PathMeasure pathMeasure1 = new PathMeasure(paramPath, false);
        int k = Math.min(100, (int)(f1 / paramFloat) + 1);
        float[] arrayOfFloat2 = new float[k];
        float[] arrayOfFloat1 = new float[k];
        float[] arrayOfFloat3 = new float[2];
        int j = 0;
        f1 /= (k - 1);
        paramFloat = 0.0F;
        int i = 0;
        while (i < k) {
          pathMeasure1.getPosTan(paramFloat, arrayOfFloat3, null);
          pathMeasure1.getPosTan(paramFloat, arrayOfFloat3, null);
          arrayOfFloat2[i] = arrayOfFloat3[0];
          arrayOfFloat1[i] = arrayOfFloat3[1];
          f = paramFloat + f1;
          int m = j;
          paramFloat = f;
          if (j + 1 < arrayList.size()) {
            m = j;
            paramFloat = f;
            if (f > ((Float)arrayList.get(j + 1)).floatValue()) {
              paramFloat = f - ((Float)arrayList.get(j + 1)).floatValue();
              m = j + 1;
              pathMeasure1.nextContour();
            } 
          } 
          i++;
          j = m;
        } 
        pathMeasure1 = null;
        arrayList = null;
        if (paramString1 != null)
          propertyValuesHolder1 = PropertyValuesHolder.ofFloat(paramString1, arrayOfFloat2); 
        ArrayList<Float> arrayList1 = arrayList;
        if (paramString2 != null)
          propertyValuesHolder2 = PropertyValuesHolder.ofFloat(paramString2, arrayOfFloat1); 
        if (propertyValuesHolder1 == null) {
          paramObjectAnimator.setValues(new PropertyValuesHolder[] { propertyValuesHolder2 });
          return;
        } 
        if (propertyValuesHolder2 == null) {
          paramObjectAnimator.setValues(new PropertyValuesHolder[] { propertyValuesHolder1 });
          return;
        } 
        paramObjectAnimator.setValues(new PropertyValuesHolder[] { propertyValuesHolder1, propertyValuesHolder2 });
        return;
      } 
    } 
  }
  
  private static class PathDataEvaluator implements TypeEvaluator<PathParser.PathDataNode[]> {
    private PathParser.PathDataNode[] mNodeArray;
    
    private PathDataEvaluator() {}
    
    PathDataEvaluator(PathParser.PathDataNode[] param1ArrayOfPathDataNode) {
      this.mNodeArray = param1ArrayOfPathDataNode;
    }
    
    public PathParser.PathDataNode[] evaluate(float param1Float, PathParser.PathDataNode[] param1ArrayOfPathDataNode1, PathParser.PathDataNode[] param1ArrayOfPathDataNode2) {
      if (!PathParser.canMorph(param1ArrayOfPathDataNode1, param1ArrayOfPathDataNode2))
        throw new IllegalArgumentException("Can't interpolate between two incompatible pathData"); 
      if (this.mNodeArray == null || !PathParser.canMorph(this.mNodeArray, param1ArrayOfPathDataNode1))
        this.mNodeArray = PathParser.deepCopyNodes(param1ArrayOfPathDataNode1); 
      int i;
      for (i = 0; i < param1ArrayOfPathDataNode1.length; i++)
        this.mNodeArray[i].interpolatePathDataNode(param1ArrayOfPathDataNode1[i], param1ArrayOfPathDataNode2[i], param1Float); 
      return this.mNodeArray;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Champions Cricket-dex2jar.jar!\android\support\graphics\drawable\AnimatorInflaterCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */