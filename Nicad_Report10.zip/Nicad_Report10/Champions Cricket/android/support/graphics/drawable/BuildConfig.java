package android.support.graphics.drawable;

public final class BuildConfig {
  public static final String APPLICATION_ID = "android.support.graphics.drawable";
  
  public static final String BUILD_TYPE = "release";
  
  public static final boolean DEBUG = false;
  
  public static final String FLAVOR = "";
  
  public static final int VERSION_CODE = -1;
  
  public static final String VERSION_NAME = "";
}


/* Location:              C:\soft\dex2jar-2.0\Champions Cricket-dex2jar.jar!\android\support\graphics\drawable\BuildConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */